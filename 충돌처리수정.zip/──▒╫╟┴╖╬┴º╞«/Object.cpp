#include "Object.h"
#pragma once
CObject::CObject(void)
{
	m_x = 0;
	m_y = 0;
	m_z = 0;
	m_Speed = 0;

}
CObject::~CObject(void)
{

}
void CObject::XMove(float speed)
{
	m_x = m_x + speed;
	//glPushMatrix();
	glTranslatef(m_x , 0, 0);
	//glPopMatrix();
}
void CObject::ZMove(float speed)
{
	m_z = m_z - speed;
	//glPushMatrix();
	glTranslatef(0, 0, m_z );
	//glPopMatrix();
}
CObject* CObject::Create(void)
{
	CObject*	pInstance = new CObject;


	return pInstance;
}

void CObject::Release(void)
{

	delete this;
}
void CObject::Draw(void)
{
	if (isColideRing == true)
	{
		//PlaySound(TEXT("Ring.wav"),NULL, SND_SYNC &&SND_FILENAME);

		//PlaySound(NULL, NULL, SND_ASYNC);
	}
	else
	{
		glPushMatrix();
		static float Angle = 0.0f;
		glTranslatef(m_x, m_y, m_z);
		glRotatef(Angle++, 0, 1, 0);
		////��ü �ܹ��� ǥ��
		//glPushMatrix();
		//static int RUNFRAME = 0;
		//static int RUNCNT = 0;
		//RUNFRAME++;
		//if (4 <= RUNFRAME)
		//{
		//	RUNCNT++;
		//	RUNFRAME = 0;
		//}
		//if (RUNCNT % 2 == 1)
		//	glTranslatef(0, 10, 0);
		//if (RUNCNT % 2 == 0)
		//	glTranslatef(0, -10, 0);

		//glBlendFunc(GL_ONE_MINUS_DST_COLOR, GL_ZERO);
		glColor4f(1, 1, 0, 0.5);
		//glTranslated(100,0,0);
		glutSolidTorus(1, 5, 10, 10);

		glPopMatrix();
	}

	//��ü �ܹ��� ǥ��
	
}
void CObject::Init(GLfloat x, GLfloat y, GLfloat z)
{
	m_x = x;
	m_y = y;
	m_z = z;

}
void CObject::RedDraw(void)
{
	if (isColideRing == true)
	{
		glPushMatrix();
		glTranslatef(m_x, m_y, m_z);

		glColor4f(1, 0, 0, 0.5);
		//glTranslated(100,0,0);
		glutSolidSphere(15, 20, 20);

		glPopMatrix();

	}
	else
	{
		glPushMatrix();
		glTranslatef(m_x, m_y, m_z);

		glColor3f(0, 0, 1);
		glutSolidSphere(15, 20, 20);

		glPopMatrix();
	}
	//��ü �ܹ��� ǥ��

}
void CObject::GetChange_POSITION(float xspeed, float yspeed, float zspeed)
{
	Change_x = m_x + xspeed;
	Change_y = m_y + yspeed;
	Change_z = m_z + zspeed;
}