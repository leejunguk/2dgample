#include "Obstacle.h"


CObstacle::CObstacle(void)
{


}
CObstacle::~CObstacle(void)
{

}
void CObstacle::InitPosition(float x, float y, float z)
{

	m_x = x;
	m_y = y;
	m_z = z;

}
void CObstacle::Draw(void)
{
	glPushMatrix();
	glTranslatef(m_x, m_y, m_z);

	glColor3f(1, 1, 0);
	glScalef(1,3,1);
	glutSolidCube(20);
	
	glPushMatrix();
	glColor3f(0,1,0);
	glTranslatef(0,10,0);
	glScalef(2, 0.3, 2);
	glutSolidSphere(20,15,15);
	glPopMatrix();

	glPopMatrix();
}
void CObstacle::Move(float Speed)
{
	if (m_y - Speed <= -200)
		m_Delete = true;
	glTranslatef(m_x, m_y - Speed, m_z);
}
void CObstacle::TestMove(float Speed)
{
	if (m_y - Speed <= -200)
	{
		//TestMoveZ(Speed);
	}
	glTranslatef(m_x- Speed, m_y  , m_z);
	
}
void CObstacle::TestMoveZ(float Speed)
{
	glTranslatef(m_x , m_y, m_z - Speed);
}
CObstacle* CObstacle::Create()
{

	CObstacle*	pInstance = new CObstacle;
	return pInstance;
}
void CObstacle::Relase(void)
{
	delete this;
}
bool CObstacle::GetDelete(void)
{
	return m_Delete;
}
void CObstacle::DrawTrain(void)
{
	glPushMatrix();
	glTranslatef(m_x, m_y, m_z);

	glColor3f(1, 0, 1);
	glScalef(3, 1, 3);
	glutSolidCube(20);

	glPushMatrix();
		glTranslatef(30,0,0);
		glutSolidCube(20);
	

	glPushMatrix();
		glTranslatef(30, 0, 0);
		glutSolidCube(20);
	glPopMatrix();

	glPopMatrix();
	

	glPopMatrix();
}