
#include "Defines.h"
#include "Obstacle.h"
#include "Cart.h"
#include "SnowBall.h"


using namespace std;
// �ʿ��� ���� ���� ��

int Scene_flag = 1;
const int FrontView = 2;
const int TopView = 1;
bool MouseTestOn = false;
bool SnowOn = false;
bool RainOn = false;
bool CarmeraOn = false;

float Height = 0;

void Keyboard(unsigned char key, int x, int y);
void TimerFunction(int value);
void Reshape(int w, int h);
void DrawScene();
void SetupRC();
void DrawGrond();
//Test
void CurveTest();
void MyMouseClick(GLint button, GLint state, GLint x, GLint y);
void MyMouseMove(GLint x, GLint y);
void MouseClickTest(GLint button, GLint state, GLint x, GLint y);
void MousePositionTest(GLint button, GLint state, GLint x, GLint y);
void drawPointCube();
void drawBSpline2();

void FuctionBSpline();
void FuctionBSpline1();
void FuctionBSpline2();

static float AmbientR = 0.5;
static float AmbientG = 0.5;
static float AmbientB = 0.5;
static float AmbientA = 0.5f;

static float DiffuseR = 0.5;
static float DiffuseG = 0.5;
static float DiffuseB = 0.5;
static float DiffuseA = 0.5f;

static float SpecularR = 0.5;
static float SpecularG = 0.5;
static float SpecularB = 0.5;
static float SpecularA = 0.5f;

static float ViewRotateXAngle = 0.0f;
static float ViewRotateYAngle = 0.0f;
static float ViewZOOMIN = 0.0f;

static int clickCnt = 0;
static int clickCnt2 = 0;
//�ǽ�

GLfloat tempX ;
GLfloat tempY ;
//�����Ӽ�
GLfloat gray[] = { 0.75f, 0.75f, 0.75f, 1.0f };
GLfloat  specref[] = { 1.0f, 1.0f, 1.0f, 1.0f };
CObstacle * obstacle = new CObstacle[20];
CSnowBall * Snowballs = new CSnowBall[250];
CSnowBall * Rainballs = new CSnowBall[250];
CObstacle * TestTrain = new CObstacle;
// Test Code
// Test Spline
//GLUnurbsObj* TestGlut = gluNewNurbsRenderer();
//void gluNurbsProperty(GLUnurbsObj* nObj, GLenum p, GLfloat value);
//
//void gluNurvsCurve(GLUnurbsObj* nObj, GLint nKnots, GLfloat* knot,
//	GLint stride, GLfloat* ctrlArr, GLint order, GLenum type);
//void gluDeleteNurbsRender(GLUnurbsObj* nObj);

const int N_POINTS = 6; //BSPline �������Ǽ�
const int N_DIM = 4;    //����+1 --> 3�� b���ö���
GLfloat knotVector[N_POINTS + N_DIM] = { 0,0,0,0,1,2,3,3,3,3 };//�ŵ� ����
GLfloat knotVector2[N_POINTS + N_DIM] = { 0,0,0,0,1,2,3,3,3,3 };
//GLfloat ctrlPoints[N_POINTS][4] = { {20,100,0,1},{40,180,0,1},{270,510,0,3},//���� b
//{120,30,0,1},{150,40,0,1},{180,110,0,1} };

GLfloat ctrlPoints[N_POINTS][4];
GLfloat ctrlPoints2[N_POINTS][4];

//������ ��ǥ

void drawBSpline();
//Test Spline

struct Curve
{
	GLfloat x, y;
	bool isContinue;
	bool isDrawing;
	GLfloat RGB[3];
};
struct Curve curve[100000];     //����� ��ǥ�� ������ ����ü�迭
GLint index = 0;       //���� ����� ����� ��ǥ��ġ
GLfloat selectColor[3] = { 1.0, 0.0, 0.0 }; //���õ� ���� (�⺻�� Red)
bool isDrawing = false;

//

void main()
{
	// ������ �ʱ�ȭ �� ����
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 600);
	glutCreateWindow("Points Drawing");
	// ���� ���� �ʱ�ȭ �Լ�
	SetupRC();
	glutDisplayFunc(DrawScene); // ��� �ݹ� �Լ�
	glutReshapeFunc(Reshape); // �ٽ� �׸��� �ݹ� �Լ�
	glutKeyboardFunc(Keyboard); // Ű���� �Է� �ݹ� �Լ�
	glutMouseFunc(MouseClickTest); //test
	glutMotionFunc(MyMouseMove); //test2
	glutTimerFunc(100, TimerFunction, 1); // Ÿ�̸� �ݹ� �Լ�
	glutMainLoop(); // �̺�Ʈ ���� �����ϱ�
}
void SetupRC() {

	srand(unsigned(time(NULL)));
	for (int i = 0; i < 20; ++i)
	{
		obstacle[i].InitPosition(rand() % 4000 - 2000, 0 , rand() % 4000 - 2000);
	}

	for (int i = 0; i < 250; ++i)
	{
		Snowballs[i].InitPosition(rand() % 4000 - 2000, rand() % 500 - 250 +300, rand() % 4000 - 2000);
	}

	for (int i = 0; i < 250; ++i)
	{
		Rainballs[i].InitPosition(rand() % 4000 - 2000, rand() % 500 - 250 + 300, rand() % 4000 - 2000);
	}

	
	TestTrain->InitPosition(0, 0, 0);
	
	tempX = 0;
	tempY = 0;
	
	//gluNurbsProperty(TestGlut);
	
}

// �������� ���� ���÷��� �ݹ� �Լ�: ��� �׸��� ������ �� �Լ����� ��κ� ó�� ��
void DrawScene()
{
	glClearColor(0.0f, 0.7f, 0.8f, 0.3f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // ������, ���� ���� Ŭ���� �ϱ�
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glLoadIdentity();

	GLfloat AmbientLight[] = { AmbientR, AmbientG, AmbientB, AmbientA };
	GLfloat DiffuseLight[] = { DiffuseR, DiffuseG, DiffuseB, DiffuseA };
	GLfloat SpecularLight[] = { SpecularR, SpecularG, SpecularB, SpecularA };

	GLfloat lightPos2[] = { 100.0, 0.0,-100.0,1.0 };
	GLfloat lightPos3[] = { -100.0, 0.0,100.0,1.0 };
	GLfloat lightPos4[] = { -100.0, 0.0,-100.0,1.0 };
	GLfloat lightPos1[] = { 100.0, 200.0, 100.0, 1.0 };
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

	//�ǽ�
	static float RoatateLight = 0.0f;

	glLightfv(GL_LIGHT0, GL_AMBIENT, AmbientLight);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, DiffuseLight);
	glLightfv(GL_LIGHT0, GL_SPECULAR, SpecularLight);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos1);
	glEnable(GL_LIGHT0);
	
	


	//����

	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, gray);
	glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
	glMateriali(GL_FRONT, GL_SHININESS, 128);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_NORMALIZE);
	//gluPerspective(45,1, 1.0, 400.0);// �ʿ��� ��ȯ ��


	if (Scene_flag == TopView)
	{

		glPushMatrix();
		//gluPerspective(60.0, 1.0, 1.0, 1000.0);
		glTranslatef(0, 0, -3040);
		glRotatef(90, 1, 0, 0);

	}
	glPushMatrix();
	glRotatef(ViewRotateXAngle,1,0,0);// ��üȭ������
	glRotatef(ViewRotateYAngle, 0, 1, 0);
	glTranslatef(0,0,ViewZOOMIN);
	
	

	static float TestTrainSpeed = 0.0f;
	TestTrainSpeed += 3.0;

	if (12 <= clickCnt + clickCnt2)
	{
		glPushMatrix();
		TestTrain->Create();
		
		TestTrain->InitPosition((ctrlPoints[1][0] ) , (ctrlPoints[1][1] ) , ctrlPoints[1][2]);
		
		cout << ctrlPoints[1][0] << endl;

		//TestTrain->TestMove(TestTrainSpeed);
		TestTrain->DrawTrain();
		glPopMatrix();
	}
	//Bspline animation test
	if (12 <= clickCnt + clickCnt2)
	{
		FuctionBSpline();
		FuctionBSpline1();
		FuctionBSpline2();
	}
	//Test
	if (5 <= clickCnt)
	{
		glColor3f(0,0,0);
		glLineWidth(400000);
		drawBSpline();

		
	}

	//if(4<=clickCnt2)
	  drawBSpline2();
	
	//drawPointCube();
	

	if (MouseTestOn == true)
	{
		glPushMatrix();
		glColor3f(1,1,1);
		glTranslatef(tempX, tempY, 0);
		glutSolidCube(20);

		glPopMatrix();
	}

	DrawGrond();
	CurveTest();
	
	//coster start

	//point test
	glColor3f(1, 1, 1);
	glPointSize(5.0);
	glBegin(GL_POINTS);
	for (int i = 0; i < N_POINTS; i++)
		glVertex3fv(&ctrlPoints[i][0]);
	glEnd();	//point test
	glColor3f(0,1,0);
	glPointSize(5.0);
	glBegin(GL_POINTS);
	for (int i = 0; i < N_POINTS; i++)
		glVertex3fv(&ctrlPoints2[i][0]);
	glEnd();
	//cartline
	glColor3f(0.5, 0.5, 0.5);
	glPointSize(10.0);
	glBegin(GL_POINTS);
	for (int i = 0; i < N_POINTS; i++)
		glVertex3fv(&ctrlPoints2[i][0]);
	glEnd();
	glColor3f(0.2, 0.2, 0.2);
	glPointSize(10.0);
	glBegin(GL_POINTS);
	for (int i = 0; i < N_POINTS; i++)
		glVertex3fv(&ctrlPoints[i][0]);
	glEnd();
	//

	for (int i = 0; i < 20; ++i)
	{
		glPushMatrix();


		
		obstacle[i].Draw();

		glPopMatrix();
	}

	static float fallSnowSpeed = 0.0f;
	static float fallRainSpeed = 0.0f;
	if (SnowOn == true)
	{
		
		for (int i = 0; i < 250; ++i)
		{
			glPushMatrix();

			fallSnowSpeed +=0.02;
			Snowballs[i].Move(fallSnowSpeed);
			Snowballs[i].Draw();

			if (Snowballs[i].m_y - fallSnowSpeed <= -1000)
			{
				
				fallSnowSpeed = 0.0f;
				Snowballs[i].InitPosition(rand() % 500 - 250, rand() % 500 - 250 + 300, rand() % 500 - 250);


			}

			glPopMatrix();
		}
	}
	if (RainOn == true)
	{
		for (int i = 0; i < 250; ++i)
		{
			glPushMatrix();

			fallRainSpeed += 0.02;
			Rainballs[i].Move(fallRainSpeed);
			Rainballs[i].RainDraw();

			if (Rainballs[i].m_y - fallRainSpeed <= -300)
			{

				fallRainSpeed = 0.0f;
				Rainballs[i].InitPosition(rand() % 4000 - 2000, rand() % 500 - 250 + 300, rand() % 500 - 250);

			}

			glPopMatrix();
		}
	}




	if (Scene_flag == TopView)
	{
		glPopMatrix();
	}

	glPopMatrix();
	//ȭ������
	
	glDisable(GL_DEPTH_TEST);
	glutSwapBuffers();

}
void Reshape(int w, int h)
{
	// ����Ʈ ��ȯ ����: ��� ȭ�� ����
	glViewport(0, 0, w, h);
	// Ŭ���� ��ȯ ����: ����ϰ��� �ϴ� ���� ����
	// �Ʒ� 3���� ������ �����ϴ� �Լ�
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// ���� ������ ����ϴ� ���:

	if (Scene_flag == TopView)
	{
	
		//gluPerspective(60.0, 1.0, 1.0, 4000.0);
		//glOrtho(0.0, w, 0.0, h, -400.0, 400.0);
		gluPerspective(60.0, 1.0, 1.0, 10000.0);
	}
	else
	{
		glOrtho(0.0, w, 0.0, h, -400.0, 400.0);
		
	}
	glTranslatef(0.0, 0.0, -300.0);
	// glOrtho (0.0, 800.0, 0.0, 600.0, -1.0, 1.0);
	// �𵨸� ��ȯ ����: ���÷��� �ݹ� �Լ����� �� ��ȯ �����ϱ� ���Ͽ� Matrix mode ����
	glMatrixMode(GL_MODELVIEW);
	// ���� ��ȯ: ī�޶��� ��ġ ���� (�ʿ��� ���, �ٸ� ���� ���� ����)
	//gluLookAt(0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0);
}
void Keyboard(unsigned char key, int x, int y)
{
	if (key == '1')
	{
		Scene_flag = TopView;
	}
	if (key == '2')
	{
		Scene_flag = FrontView;
	}
	if (key == 'w' || key == 'W')
	{
		ViewRotateXAngle++;
	}
	if (key == 's' || key == 'S')
	{
		ViewRotateXAngle--;
	}
	if (key == 'a' || key == 'A')
	{
		ViewRotateYAngle++;
	}
	if (key == 'd' || key == 'D')
	{
		ViewRotateYAngle--;
	}
	if (key == '+' || key == '=')
	{
		ViewZOOMIN += 10;
	}
	if (key == '-' || key == '_')
	{
		ViewZOOMIN -= 10;
	}
	if (key == 'b' || key == 'B')
	{
		SnowOn = true;
	}
	if (key == 'r' || key =='R')
	{
		RainOn = true;
	}
	if (key=='v'||key=='V')
	{
		CarmeraOn = true;
	}
	if (key == 'h' || key == 'H')
	{
		Height+= 10;
	}
	if (key == 'l' || key == 'L')
	{
		Height-= 10;
	}

}
void TimerFunction(int value)
{
	glutPostRedisplay(); // ȭ�� ������� ���Ͽ� ���÷��� �ݹ� �Լ� ȣ��
	glutTimerFunc(100, TimerFunction, 1);
}
void DrawGrond()
{
	glPushMatrix();
	glColor3f(0.5,0.5,0);
	glTranslatef(0 ,- 20, 0);
	glScalef(1200, 1, 1200);
	glutSolidCube(5);


	glPopMatrix();
}
void CurveTest()
{
	int i=0;
	glColor3f(1,1,1);
	while (curve[i].isContinue) //������ �׸��� �۾��� �� ��������..
	{
		glBegin(GL_LINE_STRIP);
		while (curve[i].isDrawing) //���콺�� �� �������� �� ���� ������ �׸���.
		{
			glColor3f(curve[i].RGB[0], curve[i].RGB[1], curve[i].RGB[2]);
			glVertex3f(curve[i].x, curve[i].y, 0.0);
			i++;
		}
		i++;
		glEnd();
	}
	glFlush();
}
void MouseClickTest(GLint button, GLint state, GLint x, GLint y)
{
	//�� ���� ������ Ŭ���ߴ��� �˻�
	  //�Ǽ����� ��ǥ�� ��ȯ
	 //�Ǽ����� ��ǥ�� ��ȯ

	tempX = (x -400) * 5;
	tempY = (y -300) * 5 ;
	
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		static int i = 0;
		static int j = 0;

		if (N_POINTS < i  )
		{
			//clickCnt = 0;
			//i = 0;
			ctrlPoints2[0][0] = ctrlPoints[N_POINTS-1][0];
			ctrlPoints2[0][1] = ctrlPoints[N_POINTS-1][1];
			ctrlPoints2[0][2] = ctrlPoints[N_POINTS-1][2];
			ctrlPoints2[0][3] = ctrlPoints[N_POINTS-2][3];

			
			j++;
			ctrlPoints2[j][0] = tempX;
			ctrlPoints2[j][2] = tempY;
			ctrlPoints2[j][1] = Height;
			ctrlPoints2[j][3] = 1;
			clickCnt2++;
			
		}
		else
		{
			clickCnt++;
			i++;
			ctrlPoints[i][0] = tempX;
			ctrlPoints[i][2] = tempY;
			ctrlPoints[i][1] = Height;
			ctrlPoints[i][3] = 1;
		}
		cout << ctrlPoints[1][0] << endl;

		
			
	}
	

}
void MousePositionTest(GLint button, GLint state, GLint x, GLint y)
{
	 tempX = x  ;
	 tempY = -y + 600;
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		MouseTestOn = true;
		
	}

}
void MyMouseClick(GLint button, GLint state, GLint x, GLint y)
{
	//�� ���� ������ Ŭ���ߴ��� �˻�
	GLfloat tempX = x / 500.0;   //�Ǽ����� ��ǥ�� ��ȯ
	GLfloat tempY = (500 - y) / 500.0; //�Ǽ����� ��ǥ�� ��ȯ
	if ((tempX <= 1.0 && tempX >= 0.95) && (tempY <= 1.0 && tempY >= 0.85))
	{
		if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
		{
			//
			//�� ���� ������ Ŭ���Ͽ����� �˻�
			if (tempY <= 1.0 && tempY >= 0.95) //Red �÷� ����
			{
				selectColor[0] = 1.0; selectColor[1] = 0.0; selectColor[2] = 0.0;
			}
			else if (tempY <= 0.95 && tempY >= 0.9) //Green �÷� ����
			{
				selectColor[0] = 0.0; selectColor[1] = 1.0; selectColor[2] = 0.0;
			}
			else if (tempY <= 0.9 && tempY >= 0.85) //Blue�÷� ����
			{
				selectColor[0] = 0.0; selectColor[1] = 0.0; selectColor[2] = 1.0;
			}
		}
	}
	else if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		isDrawing = true; //�׸��� ���� (��ǥ�� ����)
	}
	else if (button == GLUT_LEFT_BUTTON && state == GLUT_UP)
	{
		isDrawing = false;     //���콺�� ��ư�� ����, �׸����۾� �ߴ�
		curve[index - 1].isDrawing = false; //�迭�� �׸��� �ߴ����� ǥ��
	}
	else if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		for (int i = 0; i < 100000; i++)  //����ü �迭 �ʱ�ȭ �۾�
		{
			curve[i].isContinue = false;
			curve[i].isDrawing = false;
			curve[i].RGB[0] = 1.0;
			curve[i].RGB[1] = 0.0;
			curve[i].RGB[2] = 0.0;
			curve[i].x = 0.0;
			curve[i].y = 0.0;
		}
		index = 0;
		glutPostRedisplay();
	}
}
void MyMouseMove(GLint x, GLint y)
{
	//���� �׸� ��ǥ�� ��ġ�� ��´�.
	if (isDrawing)
	{
		curve[index].x = x / 500.0;
		curve[index].y = (500 - y) / 500.0;
		curve[index].isContinue = true;
		curve[index].isDrawing = true;
		curve[index].RGB[0] = selectColor[0];
		curve[index].RGB[1] = selectColor[1];
		curve[index].RGB[2] = selectColor[2];
		index++;
		glutPostRedisplay();
	}
}

//Test Spline
void drawBSpline()
{
	GLUnurbsObj* cubicBSplnCurve;
	cubicBSplnCurve = gluNewNurbsRenderer();
	gluNurbsProperty(cubicBSplnCurve, GLU_SAMPLING_METHOD, GLU_PATH_LENGTH);
	gluNurbsProperty(cubicBSplnCurve, GLU_SAMPLING_TOLERANCE, 10.0); //�������� 10�ȳѰ�

	gluBeginCurve(cubicBSplnCurve);
		gluNurbsCurve(cubicBSplnCurve,N_POINTS + N_DIM,
			knotVector, 4, &ctrlPoints[0][0], N_DIM, GL_MAP1_VERTEX_4);
	gluEndCurve(cubicBSplnCurve);
	gluDeleteNurbsRenderer(cubicBSplnCurve);
}
void drawBSpline2()
{
	GLUnurbsObj* cubicBSplnCurve;
	cubicBSplnCurve = gluNewNurbsRenderer();
	gluNurbsProperty(cubicBSplnCurve, GLU_SAMPLING_METHOD, GLU_PATH_LENGTH);
	gluNurbsProperty(cubicBSplnCurve, GLU_SAMPLING_TOLERANCE, 10.0); //�������� 10�ȳѰ�

	gluBeginCurve(cubicBSplnCurve);
	gluNurbsCurve(cubicBSplnCurve, N_POINTS + N_DIM,
		knotVector, 4, &ctrlPoints2[0][0], N_DIM, GL_MAP1_VERTEX_4);
	gluEndCurve(cubicBSplnCurve);
	gluDeleteNurbsRenderer(cubicBSplnCurve);
}

void drawPointCube()
{
	//static int i = 0;
	for (int i = 0; i < N_POINTS; ++i)
	{
		glPushMatrix();
		glColor3f(1, 1, 1);
		glTranslatef(3*ctrlPoints[i][0],  -3*ctrlPoints[i][2], ctrlPoints[i][1]);
		glutSolidCube(20);
		glPopMatrix();
	}
	
}

void FuctionBSpline()
{
	//P(t) = (1-t)2 P0 + 2t(1-t) P1 + t2 P2, 0<= t< 1
	glColor3f(1, 1, 1);
	static int cnttmp = 0;
	static float i = 0.01;
	static float j = 0.01;
	static float k = 0.01;
	static float q = 0.01;
	static float i1 = 0;
	static float j1 = 0;
	static float k1 = 0;
	static float q1 = 0;
	float CartSpeed = 0.02;
	static float xMove = 0;
	xMove++;
	glPushMatrix();

	
		if (1 <= q)
		{
			i = 0;
			j = 0;
			k = 0;
			q = 0;

		}
		else if (1<=k)
		{
			glTranslatef((1 - q) *(1 - q)* ctrlPoints2[2][0] + 2 * q*(1 - q)*ctrlPoints2[3][0] + q*q* ctrlPoints2[4][0], (1 - q) *(1 - q)* ctrlPoints2[2][1] + 2 * q*(1 - q)*ctrlPoints2[3][1] + q*q* ctrlPoints2[4][1], (1 - q) *(1 - q)* ctrlPoints2[2][2] + 2 * q*(1 - q)*ctrlPoints2[3][2] + q*q* ctrlPoints2[4][2]);
			q += CartSpeed;

		}
		else if (1<=j)
		{
			glTranslatef((1 - k) *(1 - k)* ctrlPoints[5][0] + 2 * k*(1 - k)*ctrlPoints2[1][0] + k*k* ctrlPoints2[2][0], (1 - k) *(1 - k)* ctrlPoints[5][1] + 2 * k*(1 - k)*ctrlPoints2[1][1] + k*k* ctrlPoints2[2][1], (1 - k) *(1 - k)* ctrlPoints[5][2] + 2 * k*(1 - k)*ctrlPoints2[1][2] + k*k* ctrlPoints2[2][2]);
			k += CartSpeed;
		}
		else if (1 <= i)
		{
			glTranslatef((1 - j) *(1 - j)* ctrlPoints[3][0] + 2 * j*(1 - j)*ctrlPoints[4][0] + j*j* ctrlPoints[5][0], (1 - j) *(1 - j)* ctrlPoints[3][1] + 2 * j*(1 - j)*ctrlPoints[4][1] + j*j* ctrlPoints[5][1], (1 - j) *(1 - j)* ctrlPoints[3][2] + 2 * j*(1 - j)*ctrlPoints[4][2] + j*j* ctrlPoints[5][2]);
			
			j += CartSpeed;
		}
		else
		{
			if (cnttmp == 0)
			{


				
				cnttmp++;

				// ù���ʱ�ȭ
			}
			
			
			//glTranslatef(ctrlPoints[1][0], ctrlPoints[1][1], ctrlPoints[1][2]);
			glTranslatef((1 - i) *(1 - i)* ctrlPoints[1][0] + 2 * i*(1 - i)*ctrlPoints[2][0] + i*i* ctrlPoints[3][0], (1 - i) *(1 - i)* ctrlPoints[1][1] + 2 * i*(1 - i)*ctrlPoints[2][1] + i*i* ctrlPoints[3][1], (1 - i) *(1 - i)* ctrlPoints[1][2] + 2 * i*(1 - i)*ctrlPoints[2][2] + i*i* ctrlPoints[3][2]);
			
			//glTranslatef(0, 0, 200);
			i += CartSpeed;
		}
	
	glutSolidCube(50);
	
	


	glPopMatrix();
}
void FuctionBSpline1()
{
	//P(t) = (1-t)2 P0 + 2t(1-t) P1 + t2 P2, 0<= t< 1
	glColor3f(1, 1, 1);
	static int cnttmp = 0;
	static float i = 0.05;
	static float j = 0.05;
	static float k = 0.05;
	static float q = 0.05;
	static float i1 = 0;
	static float j1 = 0;
	static float k1 = 0;
	static float q1 = 0;
	float CartSpeed = 0.02;
	static float xMove = 0;
	xMove++;
	glPushMatrix();


	if (1 <= q)
	{
		i = 0;
		j = 0;
		k = 0;
		q = 0;

	}
	else if (1 <= k)
	{
		glTranslatef((1 - q) *(1 - q)* ctrlPoints2[2][0] + 2 * q*(1 - q)*ctrlPoints2[3][0] + q*q* ctrlPoints2[4][0], (1 - q) *(1 - q)* ctrlPoints2[2][1] + 2 * q*(1 - q)*ctrlPoints2[3][1] + q*q* ctrlPoints2[4][1], (1 - q) *(1 - q)* ctrlPoints2[2][2] + 2 * q*(1 - q)*ctrlPoints2[3][2] + q*q* ctrlPoints2[4][2]);
		q += CartSpeed;

	}
	else if (1 <= j)
	{
		glTranslatef((1 - k) *(1 - k)* ctrlPoints[5][0] + 2 * k*(1 - k)*ctrlPoints2[1][0] + k*k* ctrlPoints2[2][0], (1 - k) *(1 - k)* ctrlPoints[5][1] + 2 * k*(1 - k)*ctrlPoints2[1][1] + k*k* ctrlPoints2[2][1], (1 - k) *(1 - k)* ctrlPoints[5][2] + 2 * k*(1 - k)*ctrlPoints2[1][2] + k*k* ctrlPoints2[2][2]);
		k += CartSpeed;
	}
	else if (1 <= i)
	{
		glTranslatef((1 - j) *(1 - j)* ctrlPoints[3][0] + 2 * j*(1 - j)*ctrlPoints[4][0] + j*j* ctrlPoints[5][0], (1 - j) *(1 - j)* ctrlPoints[3][1] + 2 * j*(1 - j)*ctrlPoints[4][1] + j*j* ctrlPoints[5][1], (1 - j) *(1 - j)* ctrlPoints[3][2] + 2 * j*(1 - j)*ctrlPoints[4][2] + j*j* ctrlPoints[5][2]);

		j += CartSpeed;
	}
	else
	{
		if (cnttmp == 0)
		{



			cnttmp++;

			// ù���ʱ�ȭ
		}


		//glTranslatef(ctrlPoints[1][0], ctrlPoints[1][1], ctrlPoints[1][2]);
		glTranslatef((1 - i) *(1 - i)* ctrlPoints[1][0] + 2 * i*(1 - i)*ctrlPoints[2][0] + i*i* ctrlPoints[3][0], (1 - i) *(1 - i)* ctrlPoints[1][1] + 2 * i*(1 - i)*ctrlPoints[2][1] + i*i* ctrlPoints[3][1], (1 - i) *(1 - i)* ctrlPoints[1][2] + 2 * i*(1 - i)*ctrlPoints[2][2] + i*i* ctrlPoints[3][2]);

		//glTranslatef(0, 0, 200);
		i += CartSpeed;
	}

	glutSolidCube(50);




	glPopMatrix();

}
void FuctionBSpline2()
{
	//P(t) = (1-t)2 P0 + 2t(1-t) P1 + t2 P2, 0<= t< 1
	glColor3f(1, 1, 1);
	static int cnttmp = 0;
	static float i = 0.10;
	static float j = 0.10;
	static float k = 0.10;
	static float q = 0.10;
	static float i1 = 0;
	static float j1 = 0;
	static float k1 = 0;
	static float q1 = 0;
	float CartSpeed = 0.02;
	static float xMove = 0;
	xMove++;
	glPushMatrix();


	if (1 <= q)
	{
		i = 0;
		j = 0;
		k = 0;
		q = 0;

	}
	else if (1 <= k)
	{
		glTranslatef((1 - q) *(1 - q)* ctrlPoints2[2][0] + 2 * q*(1 - q)*ctrlPoints2[3][0] + q*q* ctrlPoints2[4][0], (1 - q) *(1 - q)* ctrlPoints2[2][1] + 2 * q*(1 - q)*ctrlPoints2[3][1] + q*q* ctrlPoints2[4][1], (1 - q) *(1 - q)* ctrlPoints2[2][2] + 2 * q*(1 - q)*ctrlPoints2[3][2] + q*q* ctrlPoints2[4][2]);
		q += CartSpeed;

	}
	else if (1 <= j)
	{
		glTranslatef((1 - k) *(1 - k)* ctrlPoints[5][0] + 2 * k*(1 - k)*ctrlPoints2[1][0] + k*k* ctrlPoints2[2][0], (1 - k) *(1 - k)* ctrlPoints[5][1] + 2 * k*(1 - k)*ctrlPoints2[1][1] + k*k* ctrlPoints2[2][1], (1 - k) *(1 - k)* ctrlPoints[5][2] + 2 * k*(1 - k)*ctrlPoints2[1][2] + k*k* ctrlPoints2[2][2]);
		k += CartSpeed;
	}
	else if (1 <= i)
	{
		glTranslatef((1 - j) *(1 - j)* ctrlPoints[3][0] + 2 * j*(1 - j)*ctrlPoints[4][0] + j*j* ctrlPoints[5][0], (1 - j) *(1 - j)* ctrlPoints[3][1] + 2 * j*(1 - j)*ctrlPoints[4][1] + j*j* ctrlPoints[5][1], (1 - j) *(1 - j)* ctrlPoints[3][2] + 2 * j*(1 - j)*ctrlPoints[4][2] + j*j* ctrlPoints[5][2]);

		j += CartSpeed;
	}
	else
	{
		if (cnttmp == 0)
		{



			cnttmp++;

			// ù���ʱ�ȭ
		}


		//glTranslatef(ctrlPoints[1][0], ctrlPoints[1][1], ctrlPoints[1][2]);
		glTranslatef((1 - i) *(1 - i)* ctrlPoints[1][0] + 2 * i*(1 - i)*ctrlPoints[2][0] + i*i* ctrlPoints[3][0], (1 - i) *(1 - i)* ctrlPoints[1][1] + 2 * i*(1 - i)*ctrlPoints[2][1] + i*i* ctrlPoints[3][1], (1 - i) *(1 - i)* ctrlPoints[1][2] + 2 * i*(1 - i)*ctrlPoints[2][2] + i*i* ctrlPoints[3][2]);

		//glTranslatef(0, 0, 200);
		i += CartSpeed;
	}

	glutSolidCube(50);




	glPopMatrix();

}