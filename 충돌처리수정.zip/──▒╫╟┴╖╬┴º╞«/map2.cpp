#include <GL/glut.h>
#include <iostream>
#include <math.h>
#include <time.h>
#include "Sonic.h"
#include "Object.h"
//#include "Defines.h"
#include <stdio.h> // ��� ���� ���� 
#include <windows.h> // ��Ʈ�� ���� ���� �ڷ� ���� 

GLubyte *pBytes; // �����͸� ����ų ������ 
BITMAPINFO *info; // ��Ʈ�� ��� ������ ����


GLubyte * LoadDIBitmap(const char *filename, BITMAPINFO **info);
void RingColideCheck(CSonic* pPlayer, CObject* pRing);


#define TIME 100
#define PI 3.1451927
#define map_weight 600
#define map_height 500
#define map_depth  500
#define move_right 0
#define move_left 1
#define move_go 2
#define see_right 3
#define see_left 4
#define see_front 5
#define see_behind 6

GLvoid DrawScene();
GLvoid Reshape(int w, int h);
GLvoid TimerFunction(int);
GLvoid Keyboard(unsigned char, int, int);
void SpecialKeyboard(int key, int x, int y);


////////////////////////////

float eye_x = 0, eye_y = 100.0, eye_z = 200;
float test_y = 0;
float test_x = 30;
float rot_x = 0, rot_y = 0, rot_z = 0;
float angle = 0.0f;

float move_object_x = 0.0;
float move_object_y = 0.0;
float move_object_z = 0.0;


float rotate_2013180017 = 0;
float rotate_moon = 0;
float rotate_light = 0;

float see = 0;
float see_total = 0;
int move_state = move_go;
int see_state = see_front;

const int amount_snow = 1000;

float ambient_light = 0;
float diffuse_light = 1.0;
float specular_light = 1.0;


bool turn_1 = true;
bool normal = true;

////�׽�Ʈ
float u = 0, v = 1;

///////////////////////////////////////////////����
GLuint textures[6];

typedef struct Snow {
	float x, y, z;
};

Snow snow[amount_snow];
// �Ҵ� ���� �ڵ�
CSonic* Sonic = NULL;
CObject* Ring;

//�߾� ������Ʈ
CObject* Snowlist = new CObject[30];
CObject* LeftRinglist = new CObject[30];
CObject* RightRedlist = new CObject[30];

void main()

{
	srand(unsigned(time(NULL)));

	for (int i = 0; i < amount_snow; i++) {
		snow[i].x = rand() % 2000 - 1000;
		snow[i].y = rand() % 2000 - 1000;
		snow[i].z = rand() % 2000 - 1000;
	}

	// n���� �̹��� �ؽ�ó ������ �Ѵ�.  
	glGenTextures(1, textures);
	//�ؽ�ó�� ��ü�� �����Ѵ�.  --- (1)  
	glBindTexture(GL_TEXTURE_2D, textures[0]);
	//�̹��� �ε��� �Ѵ�.  --- (2)  
	pBytes = LoadDIBitmap("tile.bmp", &info);



	// �ؽ�ó ���� Ȱ��ȭ

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowPosition(400, 400);
	glutInitWindowSize(800, 600);
	glutCreateWindow("14");

	//
	//SetupRC();

	//
	glutDisplayFunc(DrawScene);
	glutReshapeFunc(Reshape);
	glutTimerFunc(100, TimerFunction, 1);
	glutKeyboardFunc(Keyboard);
	glutSpecialFunc(SpecialKeyboard);

	glutMainLoop();
}


GLvoid DrawScene() {

	glClearColor(0.0f, 0.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();

	Sonic = Sonic->Create();
	Ring = Ring->Create();

	//0������
	GLfloat AmbientLight[] = { ambient_light, ambient_light, ambient_light, 0 };
	GLfloat DiffuseLight[] = { diffuse_light, diffuse_light, diffuse_light, 1.0f };
	GLfloat SpecularLight[] = { specular_light, specular_light, specular_light , 1.0 };
	GLfloat lightPos[] = { -500, 800, -300 ,1.0 };

	///
	GLfloat ambientLight[] = { 0.5, 0.5, 0.5, 0 };
	GLfloat specref[] = { 1.0f, 1.0f, 1.0f, 1.0f };

	//gluLookAt(0, 126, 30, 0, 110, 0, 0,1.0, 0.0);

	glTranslatef(-eye_x, -eye_y, -eye_z);

	glRotatef(test_y, 0.0f, 1.0f, 0.0f);
	glRotatef(test_x, 1.0f, 0.0f, 0.0f);


	glEnable(GL_DEPTH_TEST);
	// ���� ȿ���� �����Ѵ�.
	glPushMatrix();
	glEnable(GL_LIGHTING);
	glEnable(GL_NORMALIZE);
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
	/*glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, 0.0);
	glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, 0.0);*/

	// ���� ����
	//���� 0��
	//glRotatef(rotate_2013180017, 1, 0, 0);

	glLightfv(GL_LIGHT0, GL_AMBIENT, AmbientLight);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, DiffuseLight);
	glLightfv(GL_LIGHT0, GL_SPECULAR, SpecularLight);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	if (turn_1 == true)
		glEnable(GL_LIGHT0);
	else glDisable(GL_LIGHT0);


	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

	glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
	glMateriali(GL_FRONT, GL_SHININESS, 128);




	//�ؽ�ó ���� ���Ǹ� �Ѵ�.  --- (3)
	glTexImage2D(GL_TEXTURE_2D, 0, 3, 512, 512, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, pBytes);
	//�ؽ�ó �Ķ���� ����   --- (4) 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// �ؽ�ó ��� ���� 
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, GL_MODULATE);

	glPopMatrix();

	glEnable(GL_TEXTURE_2D);

	/////��


	glPushMatrix();


	GLfloat ctrlpoints[3][3][3] = { { { -map_weight, 0, map_depth },{ 0, map_height, map_depth },{ map_weight, 0, map_depth } },
	{ { -map_weight, 0, 0.0 },{ 0.0, map_height, 0.0 },{ map_weight, 0, 0.0 } },
	{ { -map_weight, 0, -map_depth },{ 0, map_height, -100.0 },{ map_weight, 0, -map_depth } } };
	// ��� ������ ����
	glMap2f(GL_MAP2_VERTEX_3, 0.0, 1.0, 3, 3, 0.0, 1.0, 9, 3, &ctrlpoints[0][0][0]);
	glEnable(GL_MAP2_VERTEX_3);
	// �׸��带 �̿��� ��� �����
	glMapGrid2f(10, 0.0, 1.0, 10, 0.0, 1.0);
	// ���� �̿��Ͽ� �׸��� ����
	glEvalMesh2(GL_FILL, 0, 10, 0, 10);
	glPointSize(2.0); glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_POINTS);
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			glVertex3fv(ctrlpoints[i][j]);
	glEnd();

	glPopMatrix();


	glPushMatrix();

	GLfloat ctrlpoints3[3][3][3] = { { { -map_weight, 1, map_depth },{ 0, map_height + 1, map_depth },{ map_weight, 1, map_depth } },
	{ { -map_weight, 1, 0.0 },{ 0.0, map_height + 1, 0.0 },{ map_weight, 1, 0.0 } },
	{ { -map_weight, 1, -map_depth },{ 0, map_height + 1, -100.0 },{ map_weight, 1, -map_depth } } };
	// ��� ������ ����
	glMap2f(GL_MAP2_VERTEX_3, 0.0, 1.0, 3, 3, 0.0, 1.0, 9, 3, &ctrlpoints3[0][0][0]);
	glEnable(GL_MAP2_VERTEX_3);
	// �׸��带 �̿��� ��� �����
	glMapGrid2f(10, 0.0, 1, 10, 0.0, v);
	// ���� �̿��Ͽ� �׸��� ����
	glColor3f(0, 0, 0);
	glEvalMesh2(GL_LINE, 0, 10, 0, 10);
	glPointSize(2.0); glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_POINT);
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			glVertex3fv(ctrlpoints3[i][j]);
		}
	}
	glEnd();


	//glPopMatrix();


	//////////////////////item

	glPushMatrix();

	
	glTranslatef(0, 260, 300);
	glRotatef(see, 0, 1, 0);
	glTranslatef(0, -260, -300);
	Sonic->Init(0,260,300);


	glTranslatef(move_object_x, move_object_y, move_object_z);
	
	for (int i = 0; i < 30; ++i)
	{
		Snowlist[i].GetChange_POSITION(move_object_x, move_object_y, move_object_z);
		LeftRinglist[i].GetChange_POSITION(move_object_x, move_object_y, move_object_z);
		RightRedlist[i].GetChange_POSITION(move_object_x, move_object_y, move_object_z);
	}
	
	for (int i = 0; i < 30; ++i)
	{
		Snowlist[i].Init(0, 260, -100 * i);
		RingColideCheck(Sonic, &Snowlist[i]);
		Snowlist[i].Draw();

	}

	// left
	for (int i = 0; i < 30; ++i)
	{
		LeftRinglist[i].Init(-100, 260, -100 * i);
		RingColideCheck(Sonic, &LeftRinglist[i]);
		LeftRinglist[i].Draw();;
	}



	for (int i = 0; i < 30; ++i)
	{
		RightRedlist[i].Init(100, 260, -100 * i);
		RingColideCheck(Sonic, &RightRedlist[i]);
		RightRedlist[i].RedDraw();

	}


	glPopMatrix();




	glDisable(GL_TEXTURE_2D);
	
	
	
	
	//�Ҵ� 

	glPushMatrix();
		glTranslatef(0, 260, 300);
		glColor3f(0, 1, 0);
	//glutSolidSphere(5, 20, 20); 
			glPushMatrix();
				Sonic->Draw();
				//Ring->Draw();
			glPopMatrix();
	glPopMatrix();

	

	//////��

	glPushMatrix();
	glRotatef(rotate_2013180017, 1, 0, 0);
	for (int i = 0; i < 1000; i++) {
		glPushMatrix();
		glTranslatef(snow[i].x, snow[i].y, snow[i].z);
		glColor3f(1, 1, 1);
		glutSolidSphere(1, 10, 10);
		glTranslatef(-snow[i].x, -snow[i].y, -snow[i].z);
		glPopMatrix();
	}

	glPopMatrix();
	//////

	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glutSwapBuffers();


	Sonic->Release();

}


GLvoid TimerFunction(int value) {
	glutPostRedisplay();

	rotate_2013180017 += 10;
	
	v -= 0.08f;

	


	if (v <= 0.8)
		v = 1;
	
	
	if (move_state == move_right) {
		see += 30;
		see_total += 30;
		if (see_total >= 90) {
			move_state = move_go;
			see_total = 0;
		}
	}

	if (move_state == move_left) {
		see -= 30;
		see_total -= 30;
		if (see_total <= -90) {
			move_state = move_go;
			see_total = 0;
		} 
	}

	if( see_state == see_front )
		move_object_z += 20;
	
	else if (see_state == see_right)
		move_object_x -= 20;

	else if (see_state == see_left)
		move_object_x += 20;

	else if (see_state == see_behind)
		move_object_z -= 20;
	
	//for (int i = 0; i < amount_snow; i++) {

	//	if (snow[i].y > -20)
	//		snow[i].y -= 3;
	//	else snow[i].y = rand() % 200 + 100;
	//}

	glutTimerFunc(TIME, TimerFunction, 1);

}

GLvoid Reshape(int w, int h) {
	glViewport(0, 0, w, h);


	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(60.0, 1.0, 1.0, 800.0);
	glTranslatef(0.0, 0.0, -300.0);


	glMatrixMode(GL_MODELVIEW);
	gluLookAt(0, 0, 0, 0.0, 0, 1, 0.0, 1.0, 0.0);


}

GLvoid Keyboard(unsigned char key, int x, int y)
{


	if (key == 'y') {
		test_y++;
	}

	if (key == 'Y') {
		test_y--;
	}

	if (key == 'x') {
		test_x++;
	}

	if (key == 'X') {
		test_x--;
	}
	if (key == '-')
		eye_z += 5.0f;
	if (key == '+')
		eye_z -= 5.0f;


	if (key == 'a')
		ambient_light -= 0.1f;
	if (key == 'A')
		ambient_light += 0.1f;
	if (key == 's')
		specular_light -= 0.1f;
	if (key == 'S')
		specular_light += 0.1f;
	if (key == 'd')
		diffuse_light -= 0.1f;
	if (key == 'D')
		diffuse_light += 0.1f;





	if (key == '1') {
		if (turn_1 == true)
			turn_1 = false;
		else turn_1 = true;
	}

	if (key == 'n') {
		if (normal == true)
			normal = false;
		else normal = true;
	}
	glutPostRedisplay();
}


void SpecialKeyboard(int key, int x, int y)
{
	if (key == GLUT_KEY_RIGHT && move_state != move_right && move_state != move_left) {
		move_state = move_right;
		if (see_state == see_front)
			see_state = see_right;
		else if (see_state == see_right)
			see_state = see_behind;
		else if (see_state == see_behind)
			see_state = see_left;
		else if (see_state == see_left)
			see_state = see_front;
	}
	if (key == GLUT_KEY_LEFT && move_state != move_right && move_state != move_left) {
		move_state = move_left;
		if (see_state == see_front)
			see_state = see_left;
		else if (see_state == see_left)
			see_state = see_behind;
		else if (see_state == see_behind)
			see_state = see_right;
		else if (see_state == see_right)
			see_state = see_front;
	}
}




GLubyte * LoadDIBitmap(const char *filename, BITMAPINFO **info) {
	FILE *fp;
	GLubyte *bits;
	int bitsize, infosize;
	BITMAPFILEHEADER header;

	// ���̳ʸ� �б� ���� ������ ����
	if ((fp = fopen(filename, "rb")) == NULL)
		return NULL;
	// ��Ʈ�� ���� ����� �д´�.  
	if (fread(&header, sizeof(BITMAPFILEHEADER), 1, fp) < 1) {
		fclose(fp);
		return NULL;
	}
	// ������ BMP �������� Ȯ���Ѵ�.
	if (header.bfType != 'MB') {
		fclose(fp);
		return NULL;
	}
	// BITMAPINFOHEADER ��ġ�� ����.  
	infosize = header.bfOffBits - sizeof(BITMAPFILEHEADER);
	// ��Ʈ�� �̹��� �����͸� ���� �޸� �Ҵ��� �Ѵ�.  
	if ((*info = (BITMAPINFO *)malloc(infosize)) == NULL) {
		fclose(fp);
		exit(0);
		return NULL;
	}
	// ��Ʈ�� ���� ����� �д´�. 
	if (fread(*info, 1, infosize, fp) < (unsigned int)infosize) {
		free(*info);
		fclose(fp);
		return NULL;
	}
	// ��Ʈ���� ũ�� ����
	if ((bitsize = (*info)->bmiHeader.biSizeImage) == 0) bitsize = ((*info)->bmiHeader.biWidth *(*info)->bmiHeader.biBitCount + 7) / 8.0 *abs((*info)->bmiHeader.biHeight);
	// ��Ʈ���� ũ�⸸ŭ �޸𸮸� �Ҵ��Ѵ�.
	if ((bits = (unsigned char *)malloc(bitsize)) == NULL)
	{
		free(*info);
		fclose(fp);
		return NULL;
	}
	// ��Ʈ�� �����͸� bit(GLubyte Ÿ��)�� �����Ѵ�.
	if (fread(bits, 1, bitsize, fp) < (unsigned int)bitsize) {
		free(*info);
		free(bits);
		fclose(fp);
		return NULL;
	}
	fclose(fp);
	return bits;
}
void RingColideCheck(CSonic* pPlayer, CObject* pRing)
{
	if (pPlayer->m_x <= pRing->Change_x && pRing->Change_x <= pPlayer->m_x)
	{
		//cout << "x collide" << endl;
		if (pPlayer->m_z <= pRing->Change_z && pRing->Change_z <= pPlayer->m_z)
		{
			cout << "y collide" << endl;
			//cout << "z collide" << endl;

			//pPlayer->collideCheck = true;
			pRing->isColideRing = true;

		}

	}
}
