#include "Defines.h"

GLfloat* cardinal_hermite(float t, float tension, GLfloat p0[], GLfloat p1[], GLfloat p2[], GLfloat p3[]);
GLfloat hermite_algorithm(float u, GLfloat p0, GLfloat p1, GLfloat t0, GLfloat t1);
