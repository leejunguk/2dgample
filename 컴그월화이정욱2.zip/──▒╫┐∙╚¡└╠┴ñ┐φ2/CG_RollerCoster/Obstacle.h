#include "Defines.h"
#pragma once

class CObstacle
{
public:
	CObstacle::CObstacle(void);
	CObstacle::~CObstacle(void);
private:
	float m_x;
	float m_y;
	float m_z;
	int   m_index;
	bool  m_Delete;
public:
	virtual void CObstacle::Draw(void);
	void CObstacle::DrawTrain(void);
	void CObstacle::Move(float Speed);
	void CObstacle::TestMove(float Speed);
	void CObstacle::TestMoveZ(float Speed);
	static CObstacle* CObstacle::Create();
	void CObstacle::Relase(void);
	void CObstacle::InitPosition(float x, float y, float z);
	bool CObstacle::GetDelete(void);


};