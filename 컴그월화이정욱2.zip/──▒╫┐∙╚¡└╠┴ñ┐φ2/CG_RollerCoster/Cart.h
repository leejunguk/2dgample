#include "Obstacle.h"

class CCart :public CObstacle
{
public:
	CCart::CCart();
	CCart::~CCart();
private:
	float m_x;
	float m_y;
	float m_z;

public:
	virtual void Draw();
};
