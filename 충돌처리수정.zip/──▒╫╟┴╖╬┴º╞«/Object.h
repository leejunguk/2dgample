
#include "Defines.h"
#pragma once

//class Create pushmatrix
// ��ȯ 
// ��ο�
// popmatrix ������ �Լ��� ����.
class CObject
{
public:
	CObject::CObject(void);
	CObject::~CObject(void);
public:
	float m_x;
	float m_y;
	float m_z;
	float m_Speed;
	float Change_x;
	float Change_y;
	float Change_z;
	bool isColideRing;


public:
	CObject* CObject::Create(void);
	void CObject::Release(void);
	void CObject::Draw(void);
	void CObject::Init(GLfloat x, GLfloat y, GLfloat z);
	void CObject::XMove(float speed);
	void CObject::ZMove(float speed);
	void CObject::RedDraw(void);
	void CObject::GetChange_POSITION(float x, float y, float z);
	inline void CObject::SetSpeed(float xspeed) { m_Speed = xspeed; };
};