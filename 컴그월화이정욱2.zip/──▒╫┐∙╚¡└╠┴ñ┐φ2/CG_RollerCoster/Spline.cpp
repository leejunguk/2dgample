
#include "Spline.h"

GLfloat* cardinal_hermite(float t, float tension, GLfloat p0[], GLfloat p1[], GLfloat p2[], GLfloat p3[])
{
	GLfloat t0, t1, P0, P1;
	GLfloat pos[2];

	P0 = p1[0];
	P1 = p2[0];

	t0 = (p2[0] - p0[0]) * (1.0f - tension);
	t1 = (p3[0] - p1[0]) * (1.0f - tension);

	pos[0] = hermite_algorithm(t, P0, P1, t0, t1);

	t0 = (p2[1] - p0[1]) * (1.0f - tension);
	t1 = (p3[1] - p1[1]) * (1.0f - tension);

	pos[1] = hermite_algorithm(t, P0, P1, t0, t1);

	return pos;
}

GLfloat hermite_algorithm(float u, GLfloat p0, GLfloat p1, GLfloat t0, GLfloat t1)
{
	GLfloat s_pos;

	GLfloat u3 = u* u * u;
	GLfloat u2 = u* u;

	s_pos = (2 * p0 - 2 * p1 + t0 + t1) * u3 + (-3 * p0 + 3 * p1 - 2 * t0 - t1) * u2 + t0 *u + p0;

	return s_pos;

}