#include "Cart.h"

CCart::CCart()
{

}
CCart::~CCart()
{

}
void CCart::Draw()
{
	glPushMatrix();
	glTranslatef(m_x, m_y, m_z);

	glColor3f(0,1,1);
	glScalef(3,1,3);
	glutSolidCube(100);

	glPopMatrix();

	
}