#include <GL/glut.h>
#include <iostream>
#include <math.h>
#include <time.h>
#include <stdio.h> // ��� ���� ���� 
#include <windows.h> // ��Ʈ�� ���� ���� �ڷ� ���� 

GLubyte *pBytes; // �����͸� ����ų ������ 
BITMAPINFO *info; // ��Ʈ�� ��� ������ ����


GLubyte * LoadDIBitmap(const char *filename, BITMAPINFO **info);


#define TIME 100
#define PI 3.1451927

GLvoid DrawScene();
GLvoid Reshape(int w, int h);
GLvoid TimerFunction(int);
GLvoid Keyboard(unsigned char, int, int);


////////////////////////////

float eye_x = 0, eye_y = 400.0, eye_z = 1200;
float test_y = 0;
float test_x = 0;
float rot_x = 0, rot_y = 0, rot_z = 0;
float angle = 0.0f;

float rotate = 0;
float rotate_moon = 0;
float rotate_light = 0;


const int amount_snow = 1000;

float ambient_light = 0;
float diffuse_light = 1.0;
float specular_light = 1.0;


bool turn_1 = true;
bool normal = true;

///////////////////////////////////////////////����
GLuint textures[6];

typedef struct Snow {
	float x, y, z;
};

Snow snow[amount_snow];


void main()

{
	srand(unsigned(time(NULL)));

	for (int i = 0; i < amount_snow; i++) {
		snow[i].x = rand() % 2000 - 1000;
		snow[i].y = rand() % 2000 -1000;
		snow[i].z = rand() % 2000 - 1000;
	}

	// n���� �̹��� �ؽ�ó ������ �Ѵ�.  
	glGenTextures(1, textures);
	//�ؽ�ó�� ��ü�� �����Ѵ�.  --- (1)  
	glBindTexture(GL_TEXTURE_2D, textures[0]);
	//�̹��� �ε��� �Ѵ�.  --- (2)  
	pBytes = LoadDIBitmap("tile.bmp", &info);



	// �ؽ�ó ���� Ȱ��ȭ

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowPosition(400, 400);
	glutInitWindowSize(800, 600);
	glutCreateWindow("14");

	//
	//SetupRC();

	//
	glutDisplayFunc(DrawScene);
	glutReshapeFunc(Reshape);
	glutTimerFunc(100, TimerFunction, 1);
	glutKeyboardFunc(Keyboard);

	glutMainLoop();
}


GLvoid DrawScene() {

	glClearColor(0.0f, 0.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();



	//0������
	GLfloat AmbientLight[] = { ambient_light, ambient_light, ambient_light, 1.0f };
	GLfloat DiffuseLight[] = { diffuse_light, diffuse_light, diffuse_light, 1.0f };
	GLfloat SpecularLight[] = { specular_light, specular_light, specular_light, 1.0 };
	GLfloat lightPos[] = { 0.0, 800.0, -800.0 , 1.0 };

	///
	GLfloat ambientLight[] = { 0.2f, 0.2f, 0.2f, 1.0f };
	GLfloat specref[] = { 1.0f, 1.0f, 1.0f, 1.0f };

	glTranslatef(-eye_x, -eye_y, -eye_z);
	glRotatef(test_y, 0.0f, 1.0f, 0.0f);
	glRotatef(test_x, 1.0f, 0.0f, 0.0f);


	glEnable(GL_DEPTH_TEST);
	// ���� ȿ���� �����Ѵ�.
	glPushMatrix();
	glEnable(GL_LIGHTING);
	//glEnable(GL_NORMALIZE);
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
	glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, 0.0);
	glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, 0.0);

	// ���� ����
	//���� 0��
	//glRotatef(rotate, 0, 1, 0);

	glLightfv(GL_LIGHT0, GL_AMBIENT, AmbientLight);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, DiffuseLight);
	glLightfv(GL_LIGHT0, GL_SPECULAR, SpecularLight);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	if (turn_1 == true)
		glEnable(GL_LIGHT0);
	else glDisable(GL_LIGHT0);


	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

	glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
	glMateriali(GL_FRONT, GL_SHININESS, 128);




	//�ؽ�ó ���� ���Ǹ� �Ѵ�.  --- (3)
	glTexImage2D(GL_TEXTURE_2D, 0, 3, 512, 512, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, pBytes);
	//�ؽ�ó �Ķ���� ����   --- (4) 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// �ؽ�ó ��� ���� 
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, GL_MODULATE);

	/////0������
	glPushMatrix();
	glTranslatef(-300, 50, 100);
	glutSolidCone(5, 10, 10, 10);
	glPopMatrix();
	glPopMatrix();

	glEnable(GL_TEXTURE_2D);

	/////��


	glPushMatrix();
	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);

	//glColor3f(1, 1, 1);
	glTexGenf(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGenf(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glBindTexture(GL_TEXTURE_2D, textures[0]);

	glutSolidSphere(1000, 100, 100);

	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glPopMatrix();

	glDisable(GL_TEXTURE_2D);

	for (int i = 0; i < 1000; i++) {
		glPushMatrix();
		glTranslatef(snow[i].x, snow[i].y, snow[i].z);
		glColor3f(1, 1, 1);
		glutSolidSphere(1, 10, 10);
		glTranslatef(-snow[i].x, -snow[i].y, -snow[i].z);
		glPopMatrix();
	}
	//////

	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glutSwapBuffers();


}


GLvoid TimerFunction(int value) {
	glutPostRedisplay();

	rotate += 10;
	rotate_moon += 5;
	rotate_light += 5;


	//for (int i = 0; i < amount_snow; i++) {

	//	if (snow[i].y > -20)
	//		snow[i].y -= 3;
	//	else snow[i].y = rand() % 200 + 100;
	//}

	glutTimerFunc(TIME, TimerFunction, 1);

}

GLvoid Reshape(int w, int h) {
	glViewport(0, 0, w, h);


	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(60.0, 1.0, 1.0, 800.0);
	glTranslatef(0.0, 0.0, -300.0);


	glMatrixMode(GL_MODELVIEW);
	gluLookAt(0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0);


}

GLvoid Keyboard(unsigned char key, int x, int y)
{


	if (key == 'y') {
		test_y++;
	}

	if (key == 'Y') {
		test_y--;
	}

	if (key == 'x') {
		test_x++;
	}

	if (key == 'X') {
		test_x--;
	}
	if (key == '-')
		eye_z += 5.0f;
	if (key == '+')
		eye_z -= 5.0f;


	if (key == 'a')
		ambient_light -= 0.1f;
	if (key == 'A')
		ambient_light += 0.1f;
	if (key == 's')
		specular_light -= 0.1f;
	if (key == 'S')
		specular_light += 0.1f;
	if (key == 'd')
		diffuse_light -= 0.1f;
	if (key == 'D')
		diffuse_light += 0.1f;





	if (key == '1') {
		if (turn_1 == true)
			turn_1 = false;
		else turn_1 = true;
	}

	if (key == 'n') {
		if (normal == true)
			normal = false;
		else normal = true;
	}
	glutPostRedisplay();
}





GLubyte * LoadDIBitmap(const char *filename, BITMAPINFO **info) {
	FILE *fp;
	GLubyte *bits;
	int bitsize, infosize;
	BITMAPFILEHEADER header;

	// ���̳ʸ� �б� ���� ������ ����
	if ((fp = fopen(filename, "rb")) == NULL)
		return NULL;
	// ��Ʈ�� ���� ����� �д´�.  
	if (fread(&header, sizeof(BITMAPFILEHEADER), 1, fp) < 1) {
		fclose(fp);
		return NULL;
	}
	// ������ BMP �������� Ȯ���Ѵ�.
	if (header.bfType != 'MB') {
		fclose(fp);
		return NULL;
	}
	// BITMAPINFOHEADER ��ġ�� ����.  
	infosize = header.bfOffBits - sizeof(BITMAPFILEHEADER);
	// ��Ʈ�� �̹��� �����͸� ���� �޸� �Ҵ��� �Ѵ�.  
	if ((*info = (BITMAPINFO *)malloc(infosize)) == NULL) {
		fclose(fp);
		exit(0);
		return NULL;
	}
	// ��Ʈ�� ���� ����� �д´�. 
	if (fread(*info, 1, infosize, fp) < (unsigned int)infosize) {
		free(*info);
		fclose(fp);
		return NULL;
	}
	// ��Ʈ���� ũ�� ����
	if ((bitsize = (*info)->bmiHeader.biSizeImage) == 0) bitsize = ((*info)->bmiHeader.biWidth *(*info)->bmiHeader.biBitCount + 7) / 8.0 *abs((*info)->bmiHeader.biHeight);
	// ��Ʈ���� ũ�⸸ŭ �޸𸮸� �Ҵ��Ѵ�.
	if ((bits = (unsigned char *)malloc(bitsize)) == NULL)
	{
		free(*info);
		fclose(fp);
		return NULL;
	}
	// ��Ʈ�� �����͸� bit(GLubyte Ÿ��)�� �����Ѵ�.
	if (fread(bits, 1, bitsize, fp) < (unsigned int)bitsize) {
		free(*info);
		free(bits);
		fclose(fp);
		return NULL;
	}
	fclose(fp);
	return bits;
}

